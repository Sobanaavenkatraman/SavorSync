from prettytable import PrettyTable


class STAFF:
    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.__pay_per_day = 800

    def display_staff(self):

        row = """ SELECT staff_id, staffName, contact FROM staff"""
        rows = self.db_manager.fetch_data(row)
        return rows

    def add_staff(self, staff_name, mob_no, age):

        create_staff_table = """
            CREATE TABLE IF NOT EXISTS staff (
                staff_id INT auto_increment PRIMARY KEY,
                staffName VARCHAR(255),
                contact varchar(20),
                age INT
            )
        """
        self.db_manager.execute_query(create_staff_table)

        staff_add = f""" 
           INSERT INTO staff(staffName, contact, age)
           VALUES('{staff_name}', '{mob_no}', '{age}')
        """
        self.db_manager.execute_query(staff_add)

    def mark_attendance(self, id):

        staff_attendance = """
            CREATE TABLE IF NOT EXISTS attendance (
                attendance_id INT AUTO_INCREMENT PRIMARY KEY,
                staff_id int,
                pres_count INT DEFAULT 0, 
                abs_count INT DEFAULT 0,
                salary INT DEFAULT 0,
                FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
            ) 
        """
        self.db_manager.execute_query(staff_attendance)

        '''insert the staff_id of the staff table in the attendance table to complete the relation'''

        staff = f""" SELECT staff_id FROM attendance where staff_id = {id}"""
        data = self.db_manager.fetch_data(staff)
        if not data:
            insert_staff = f"""
                INSERT INTO attendance (staff_id) VALUES ({id});
            """
            self.db_manager.execute_query(insert_staff)

        marked = 0
        p_a = input("present - p/ absent - a: ")
        if p_a.lower() == "present" or p_a.lower() == 'p':
            mark = f""" UPDATE attendance SET pres_count = pres_count + 1
            WHERE staff_id = '{id}' """
            self.db_manager.execute_query(mark)
            self.db_manager.connection.commit()

            marked = 1

            sal = f""" UPDATE attendance SET salary = salary + {self.__pay_per_day}
            WHERE staff_id = {id} """
            self.db_manager.execute_query(sal)
            self.db_manager.connection.commit()

        elif p_a.lower() == "absent" or p_a.lower() == 'a':
            mark = f""" UPDATE attendance SET abs_count = abs_count + 1
            WHERE staff_id = {id} """
            self.db_manager.execute_query(mark)
            self.db_manager.connection.commit()

            marked = 1

        data = f"""SELECT attendance_id, staff_id, pres_count, abs_count, salary FROM attendance 
         WHERE staff_id = {id} """
        fetched_data = self.db_manager.fetch_data(data)
        display_cols = ['attendance_id', 'staff_id', 'pres_count', 'abs_count', 'salary']
        table_format = PrettyTable(display_cols)

        if fetched_data:
            for staff in fetched_data:
                table_format.add_row(staff)
            print(table_format)
        else:
            print("No data")

        if marked == 1:
            print("attendance marked")


class PtSTAFF:

    def __init__(self, db_manager):
        self.__pay_per_day = 600
        self.db_manager = db_manager

    def display_ptstaff(self):

        row = """ SELECT ptStaff_id, staffName, contact FROM ptstaff"""
        rows = self.db_manager.fetch_data(row)
        return rows

    def add_staff(self, ptStaff_id, staff_name, mob_no, age):

        pt_staff_table = """
            CREATE TABLE IF NOT EXISTS ptstaff (
                ptStaff_id varchar(255) PRIMARY KEY,
                staffName VARCHAR(255),
                contact varchar(20),
                age INT
            )
        """
        self.db_manager.execute_query(pt_staff_table)

        staff_add = f""" 
                   INSERT INTO ptstaff(ptStaff_id, staffName, contact, age)
                   VALUES('{ptStaff_id}', '{staff_name}', '{mob_no}', '{age}')
                """
        self.db_manager.execute_query(staff_add)

    def check_already_exists(self, id):

        data = f"""SELECT ptStaff_id, staffName, contact, age FROM staff WHERE ptStaff_id = '{id}' """
        fetched_data = self.db_manager.fetch_data(data)
        if fetched_data:
            last_id = fetched_data[0][0]
            print(f'continue next with {last_id}')
            return 'ID already exists'

    def mark_attendance(self, id):

        staff_attendance = """
                    CREATE TABLE IF NOT EXISTS ptAttendance (
                        pt_attendance_id INT AUTO_INCREMENT PRIMARY KEY,
                        ptStaff_id varchar(255),
                        pres_count INT DEFAULT 0, 
                        abs_count INT DEFAULT 0,
                        salary INT DEFAULT 0,
                        FOREIGN KEY (ptStaff_id) REFERENCES ptstaff(ptStaff_id)
                    )"""
        self.db_manager.execute_query(staff_attendance)

        '''insert the staff_id of the staff table in the ptAttendance table to complete the relation if not present'''

        pt_staff = f""" SELECT ptStaff_id FROM ptAttendance where ptStaff_id = '{id}' """
        pt_data = self.db_manager.fetch_data(pt_staff)
        if not pt_data :
            insert_staff = f"""
                INSERT INTO ptAttendance (ptStaff_id) VALUES ('{id}');
            """
            self.db_manager.execute_query(insert_staff)

        marked = 0
        p_a = input("present - p/ absent - a: ")
        if p_a.lower() == "present" or p_a.lower() == 'p':
            mark = f""" UPDATE ptAttendance SET pres_count = pres_count + 1
                    WHERE ptStaff_id = '{id}' """
            self.db_manager.execute_query(mark)
            self.db_manager.connection.commit()

            marked = 1

            sal = f""" UPDATE ptAttendance SET salary = salary + {self.__pay_per_day}
                    WHERE ptStaff_id = '{id}' """
            self.db_manager.execute_query(sal)
            self.db_manager.connection.commit()

        elif p_a.lower() == "absent" or p_a.lower() == 'a':
            mark = f""" UPDATE ptAttendance SET abs_count = abs_count + 1
                    WHERE ptStaff_id = '{id}' """
            self.db_manager.execute_query(mark)
            self.db_manager.connection.commit()

            marked = 1

        data = f"""SELECT pt_attendance_id, ptStaff_id, pres_count, abs_count, salary FROM ptAttendance 
                 WHERE ptStaff_id = '{id}' """
        fetched_data = self.db_manager.fetch_data(data)
        display_cols = ['attendance_id', 'staff_id', 'pres_count', 'abs_count', 'salary']
        table_format = PrettyTable(display_cols)

        if fetched_data:
            for pt_staff in fetched_data:
                table_format.add_row(pt_staff)
            print(table_format)
        else:
            print("No data")

        if marked == 1:
            print("attendance marked")


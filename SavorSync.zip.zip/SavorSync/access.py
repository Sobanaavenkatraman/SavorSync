class ACCESS:
    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.who = 'admin'
        self.pwd = 'qwertylkjh'

    def check_credentials(self, who, pwd):
        if who == self.who and pwd == self.pwd:
            return True
        return False
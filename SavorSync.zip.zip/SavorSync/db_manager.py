import pyodbc


class DatabaseManager:
    def __init__(self):
        self.connection_string = """
            DRIVER={MySQL ODBC 8.2 Unicode Driver};
            SERVER=127.0.0.1;
            PORT=3306;
            DATABASE=cafe_mgmt_sys;
            USER=root;
            PASSWORD=oct101022;
            TRUSTED_CONNECTION=Yes;   
        """
        self.connection = None
        self.cursor = None

    def connect(self):
        self.connection = pyodbc.connect(self.connection_string)
        self.cursor = self.connection.cursor()
        print("Connected to the database.")

    def execute_query(self, query):
        self.cursor.execute(query)
        self.connection.commit()

    def commit_query(self, query):
        self.cursor.commit(query)
        self.connection.commit()

    def fetch_data(self, query):
        self.cursor.execute(query)
        rows = self.cursor.fetchall()
        return rows

    def close_connection(self):
        if self.connection:
            self.connection.close()
            print("Connection closed.")




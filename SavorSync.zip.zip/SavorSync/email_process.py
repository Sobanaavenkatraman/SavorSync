import smtplib


class EMAIL:
    def __init__(self):
        self.my_email = "vsobanaa@gmail.com"
        self.pwd = "xclmvyrxxbbtheru"

    def send_email(self, address, message):
        with smtplib.SMTP("smtp.gmail.com") as connection:
            connection.starttls()
            connection.login(user=self.my_email, password=self.pwd)
            connection.sendmail(
                from_addr=self.my_email,
                to_addrs=address,
                msg=message
            )

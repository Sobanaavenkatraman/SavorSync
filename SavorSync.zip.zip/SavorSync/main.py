from prettytable import PrettyTable
from staff import STAFF, PtSTAFF
from cafe import CAFE
from db_manager import DatabaseManager
from email_process import EMAIL
import matplotlib.pyplot as plt
from access import ACCESS
from customers import CUSTOMER


def return_salary(table, id_staff):
    if table == 'staff':
        data = f"""SELECT staffName from staff WHERE  staff_id = {id_staff}"""
        st_name = db_manager.fetch_data(data)
        salary_st = f"""SELECT salary from attendance WHERE  staff_id = {id_staff} """
        salary = db_manager.fetch_data(salary_st)
        if salary[0][0] > 12800:
            salary[0][0] += salary[0][0] % 10
            '''10 % increase'''
        if salary and st_name:
            print(f"THE SALARY OF {st_name[0][0]} is : {salary[0][0]}")
        else:
            print("WRONG DETAILS. check again")

    if table == "ptStaff":
        data = f"""SELECT staffName from ptstaff WHERE  ptStaff_id = '{id_staff}' """
        st_name = db_manager.fetch_data(data)
        salary_st = f"""SELECT salary from ptAttendance WHERE  ptStaff_id = '{id_staff}' """
        salary = db_manager.fetch_data(salary_st)
        if salary and st_name:
            print(f"THE SALARY OF {st_name[0][0]} is : {salary[0][0]}")
        else:
            print("WRONG DETAILS. check again")


# ______________________________________-MAIN - CODE - _________________________________________________________



db_manager = DatabaseManager()
db_manager.connect()

cafe = CAFE(db_manager)
obj_staff = STAFF(db_manager)
obj_ptStaff = PtSTAFF(db_manager)
obj_email = EMAIL()
obj_access = ACCESS(db_manager)
obj_cust = CUSTOMER(db_manager)

cashier_pwd = 'Cafe'

access = input('Admin/customer: ')
user_name = ''
table_no, total_collection, waste_tax = 0, 0, 0
g_feed, b_feed = 0, 0
if access.lower() == 'admin':
    pwd = input("Enter access key:")

    if pwd != cashier_pwd:
        print("*_*_* ACCESS DENIED *_*_*")

    else:
        print("*_*_* ACCESS GRANTED *_*_*")

        cont = True
        while cont:
            print()
            print("Type 100 to see the user list\n\nType 1000 to see the REVENUE DATA")
            print("1. add new dishes to menu.\n2.check availability of a dish.\n3.remove dishes from menu")
            print("4.change dish price. \n5.Display menu card.\n6.Add staffs/employees \n7.View Staffs list")
            print("8.add new part time staff \n9.mark staff attendance. \n10.mark pt staff attendance")
            print("11.staff salary. \n12.Part-time workers pay. \n13.View part time staff list")
            print("14.check pending orders \n\n15.PROCESS BILL PAYMENT \n16.GIVE AWAY AMOUNT \n17.FEEDBACK REVIEW")
            print("\n18. END DAY")
            print()

            action = int(input("choose what you want to do. Choose the number : "))
            print()

            match action:

                case 1000:
                    who = input("who are you: ")
                    access_2 = input("Enter secret key: ")

                    if obj_access.check_credentials(who, pwd):
                        row = cafe.display_revenue()
                        if rows:
                            display_cols = ['day_date', 'total_collection', 'end_time', 'waste_tax']
                            table_format = PrettyTable(display_cols)
                            for person in rows:
                                table_format.add_row(person)
                            print(table_format)
                    else:
                        print("ACCESS DENIED")

                case 100:
                    '''secured details'''
                    access_1 = input("who are you: ")
                    access_2 = input("Enter secret key: ")

                    if obj_access.check_credentials(access_1, access_2):
                        rows = cafe.display_users()
                        if rows:
                            display_cols = ['customer_no', 'customerName', 'custMobNo', 'customerMail']
                            table_format = PrettyTable(display_cols)
                            if rows:
                                for person in rows:
                                    table_format.add_row(person)
                                print(table_format)

                    else:
                        print("ACCESS DENIED")

                case 1:
                    dish_name = input("Enter name of the dish to add: ")
                    dish_price = int(input("Enter price of the dish: "))
                    dish_availability = int(input("enter 1(available) or 0(unavailable): "))

                    cafe.add_dish(dish_name, dish_price, dish_availability)

                case 2:
                    dish_name = input("enter name of the dish to check availability:")

                    cafe.check_availability(dish_name)

                case 3:
                    to_do = 'delete'
                    dish_name = input("Enter name of the dish to remove:")

                    print(cafe.update_menu_card(to_do, dish_name))

                case 4:
                    to_do = 'change price'
                    dish_name = input("Enter name of the dish to change price:")

                    print(cafe.update_menu_card(to_do, dish_name))

                case 5:

                    rows = cafe.display_menu()
                    if rows:
                        print("-.-.-.-.-. DISPLAYING MENU CARD -.-.-.-.-.")
                        print()
                        display_cols = ['name', 'price']
                        table_format = PrettyTable(display_cols)
                        for dish in rows:
                            table_format.add_row(dish)
                        print(table_format)
                    else:
                        print("EMPTY MENU. START ADDING NEW DISHES :(")

                case 6:

                    staff_name = input("Enter staff's name: ")
                    mob_no = input("Enter mobile number of the staff: ")
                    age = int(input("Enter the age of the staff: "))
                    obj_staff.add_staff(staff_name, mob_no, age)

                case 7:

                    rows = staff.display_staff()
                    if rows:

                        print("-.-.-.-.-. DISPLAYING STAFFS LIST -.-.-.-.-.")
                        print()
                        display_cols = ['staff_id', 'staffName', 'contact']
                        table_format = PrettyTable(display_cols)
                        for staff in rows:
                            table_format.add_row(staff)
                        print(table_format)
                    else:
                        print("No staffs :(")

                case 8:

                    staff_id = input("assign a unique id for the staff (start with pt__): ")
                    step = obj_ptStaff.check_already_exists(staff_id)
                    if step == "ID already exists":
                        print(step)
                    else:
                        staff_name = input("enter staff name to add: ")
                        mob_no = input("enter mobile number:")
                        age = int(input("enter age of the staff: "))
                        if age < 18 or age > 55:
                            print("CANT ADD.")
                        else:
                            obj_ptStaff.add_staff(staff_id, staff_name, mob_no, age)

                case 9:
                    staff_id = int(input("Enter staff's id: "))
                    obj_staff.mark_attendance(staff_id)

                case 10:
                    staff_id = input("Enter staff's id: ")
                    obj_ptStaff.mark_attendance(staff_id)

                case 11:
                    '''staff salary only'''
                    table = "staff"
                    staff_id = int(input("Enter staff's id: "))
                    return_salary(table, staff_id)

                case 12:
                    table = "ptStaff"
                    staff_id = input("Enter staff's id (starts with pt__): ")
                    return_salary(table, staff_id)

                case 13:

                    rows = obj_ptStaff.display_ptstaff()
                    if rows:
                        print("-.-.-.-.-. DISPLAYING PART TIME STAFF'S LIST -.-.-.-.-.")
                        print()
                        display_cols = ['ptStaff_id', 'staffName', 'contact']
                        table_format = PrettyTable(display_cols)
                        for staff in rows:
                            table_format.add_row(staff)
                        print(table_format)
                    else:
                        print("No staffs :(")

                case 14:

                    rows = cafe.check_pending()
                    if rows:
                        print("-.-.-.-.-. DISPLAYING ORDERS YET TO SERVE -.-.-.-.-.")
                        print()
                        display_cols = ['table_no', 'dishes']
                        table_format = PrettyTable(display_cols)
                        for dish in rows:
                            table_format.add_row(dish)
                        print(table_format)
                    else:
                        print(":) :) ALL SERVED :) :)")

                case 15:
                    table_no = int(input("ask for table num: "))
                    table_data = cafe.process_bill(table_no)

                    if table_data:
                        bill_price = table_data[0][3]
                        wasted = input("is any food wasted?: ")

                        if wasted == 'y' or wasted == 'yes':
                            print(f"ORIG BILL AMOUNT FOR TABLE NO {table_no}: {bill_price}")
                            bill_price, waste_tax = cafe.food_waste_calc(bill_price, waste_tax)
                            print(f"revised BILL AMOUNT FOR TABLE NO {table_no}: {bill_price}")

                        elif wasted == 'n' or wasted == 'no':
                            print(f"BILL AMOUNT FOR TABLE NO {table_no}: {bill_price}")

                        bill = bill_price
                        total_collection += bill_price
                        cont = True
                        while cont:
                            got = int(input("\nAMOUNT received: "))
                            if got >= bill_price:
                                print("\nchange to be given : ", format(got - bill, '.2f'))
                            else:
                                print("\nget from customer: ", bill - got)

                            end_process = input("\nEND billing (yes/no): ")
                            if end_process == 'y' or end_process == 'yes':
                                upd_row = f"""update tables set cust_name = '', dishes = '',
                                    bill_amnt = 0 where table_no = {table_no} """
                                db_manager.execute_query(upd_row)
                                cont = False
                            else:
                                bill = bill - got
                                cont = True

                case 16:
                    print("GIVE-AWAY FOOD MAXIMUM PRICE for the day: ", waste_tax)

                case 17:

                    print("\n-.-.-.-.-. DISPLAYING FEEDBACK-.-.-.-.-.")

                    review = cafe.fetch_feed_back()
                    if review:
                        g_feed = review[0][0]
                        b_feed = review[0][1]

                        print(g_feed, b_feed)

                        plt.figure(figsize=(7, 7))
                        plt.bar(["Positive", "Negative"], [g_feed, b_feed], color=['green', 'brown'],
                                label=['Positive', 'Negative'])
                        plt.xlabel("Feedback Type")
                        plt.ylabel("Number of Feedback")
                        plt.title("Comparison of Positive and Negative Feedback")
                        plt.legend()
                        plt.show()

                case 18:

                    cafe.end_day(total_collection, waste_tax)
                    print("DAY DONE ! Thank You For The Hard Work.")
                    cont = False
                    break


            print()
            cont = input("do you wanna continue (yes / no): ").lower()
            if cont == 'no' or cont == 'n':
                cont = False
                
else:
    first_time = 0
    print("1. PLACE ORDER \n2.REGISTER FEEDBACK")
    choice = int(input("choose the number: "))
    if choice == 1:

        cont = True
        while cont:
            first_time = 1
            table_no = int(input("Enter your table number: "))
            if table_no != 0:
                user_name = input("Enter your name: ")
                if user_name != '':
                    mobile = input("Enter your mobile number: ")
                    if len(mobile) == 10:
                        email_add = input("Enter your email Id: ")
                        if email_add != '':

                            print()
                            print("-.-.-.-.-.-.-.-.-.-. WELCOME TO Casa Té -.-.-.-.-.-.-.-.-.-.")

                            user_present = obj_cust.check_user_exists(mobile)

                            if not user_present:
                                print(f"\nHello {user_name}. Seems like your first time here. \nHave a great time.")
                                msg = f"subject: Cafe_FT_20% discount. \n\nhello Mr/Mrs. {user_name} , It's amazing to have you here for the first time.Enjoy your meal with a 20% discount off your bill. COUPON_CODE : 'FT20%'. \n\nWe're Kind and so do you."
                                obj_email.send_email(email_add, msg)

                            else:
                                print(f"\nWelcome back {user_name} :) ")
                                print("Great to see you with us here again :) ")

                            print()
                            print("\n-.-.-.-.-. DISPLAYING MENU CARD -.-.-.-.-.")
                            print()

                            rows = obj_cust.display_menu()
                            display_cols = ['dishId', 'name', 'price']
                            table_format = PrettyTable(display_cols)
                            if rows:
                                for dish in rows:
                                    table_format.add_row(dish)
                                print(table_format)
                            confirm = True
                            while confirm:
                                cust_ready = input("Would you like to place your order (y/n): ")
                                if cust_ready.lower() == 'y' or 'yes':
                                    user_choices = []
                                    cont = True
                                    bill_price = 0
                                    quantity = 0
                                    print("\nNOTE !!!! MAKE SURE TO ENTER THE CORRECT VALUES :) ")
                                    print()
                                    while cont:
                                        '''Take order'''
                                        dish_id = int(input("Enter the ID of the dish you want: "))
                                        quantity = int(input("how many of this: "))

                                        dish = obj_cust.check_dish_available(dish_id)

                                        if dish:
                                            user_choices.append(dish[0][0])
                                            bill_price += (dish[0][1] * quantity)

                                        continue_order = input("\nwould you like to continue placing order (y/n): ")
                                        if continue_order.lower() == 'n' or continue_order == 'no':
                                            cont = False

                                print("\nYOUR ORDERS:  ")
                                for dish in user_choices:
                                    print(dish + ":" + str(quantity))

                                print()

                                confirming = input("can we CONFIRM the order (y/n): ").lower()

                                if confirming == 'y':
                                    coupon = input("Do you have any coupon code (yes/no): ").lower()

                                    if coupon == 'yes' or coupon == 'y':
                                        coup = ['FT_20', 'FT_20%', 'FT20', 'FT20%', 'ft20', 'ft20%', 'ft_20', 'ft_20%']
                                        code = input("Enter you coupon code: ")

                                        if code in coup:
                                            bill_price -= (bill_price/20)
                                        else:
                                            print("Invalid Coupon Code !")
                                    else:
                                        if bill_price >= 1300 and first_time != 0:
                                            bill_price -= (bill_price / 10)

                                    print("ORDER PLACED ! Have fun with our ambience while you wait")

                                    print("\n*********************")
                                    print("Join us in our mission to combat food waste and make a tangible difference with every meal! 💚🍽️ \nWhen you choose to contribute just 7% of your bill to our initiative, you're not just enjoying a delicious meal,\nyou're actively participating in the fight against food waste.")
                                    print("Every contribution counts, and every bite becomes a step towards a brighter tomorrow. ")
                                    print("\n\n\nThis is only on leaving food behind from your orders.")
                                    print("*********************")

                                    ordered = ' | '.join(''.join(inner) for inner in user_choices)
                                    cafe.update_table(user_name, ordered, bill_price, table_no)
                                    confirm = False
                                else:


                                    confirm = True


                    else:
                        print("ENTER 10 DIGITS CORRECTLY")
                        confirm = False
                else:
                    print("Do not leave it empty")
                    confirm = False
            else:
                print("enter table number to start ordering")
                confirm = False

    elif choice == 2:

        feed = input("\nEnter feedback: \n")

        print("\nThank you for your valuable feedback!")

        cafe.feed_back(feed)
class CAFE:
    def __init__(self, db_manager):
        self.db_manager = db_manager

    def update_table(self, user_name, ordered, bill_price, table_no):
        table_details = f"""update tables set cust_name = '{user_name}', dishes = '{ordered}',
            bill_amnt = {bill_price} where table_no = {table_no} """

        self.db_manager.execute_query(table_details)

    def display_revenue(self):

        row = """ * FROM Revenue"""
        rows = self.db_manager.fetch_data(row)
        return rows

    def display_users(self):

        row = """select * from users"""
        rows = self.db_manager.fetch_data(row)
        return rows

    def display_menu(self, pretty_table):

        row = """ SELECT name, price FROM Menu"""
        rows = self.db_manager.fetch_data(row)
        return rows

    def check_pending(self):

        row = """ SELECT table_no, dishes from tables where dishes != '' """
        rows = self.db_manager.fetch_data(row)
        return rows

    def add_dish(self, dish_name, dish_price, dish_availability):

        dishes_table = """
            CREATE TABLE IF NOT EXISTS Menu (
                dishId int auto_increment primary key,
                name varchar(100),
                price int,
                availability int
            )
        """
        self.db_manager.execute_query(dishes_table)

        insert_dish = f""" 
                   INSERT INTO Menu(name, price, availability)
                   VALUES( '{dish_name}', '{dish_price}', '{dish_availability}')
               """
        self.db_manager.execute_query(insert_dish)

    def update_menu_card(self, to_do, dish_name):

        if to_do == 'change price':

            check_avail = self.check_availability(dish_name)

            if check_avail.lower() == "dish available":

                row = f"""SELECT * FROM Menu where name = '{dish_name}'"""
                rows = self.db_manager.fetch_data(row)
                print(rows)

                dish_price = int(input("Enter the price you want to update with:"))

                change = f"""UPDATE Menu SET price = '{dish_price}'
                    WHERE  name = '{dish_name}'
                """
                self.db_manager.execute_query(change)
                update_row = self.db_manager.fetch_data(row)
                print(update_row)
                return "Price changed"
            else:
                return check_avail

        elif to_do == 'delete':

            check_avail = self.check_availability(dish_name)
            if check_avail.lower() == "dish available":
                deletion = f"""
                    DELETE FROM Menu 
                    WHERE name = '{dish_name}'
                """
                self.db_manager.execute_query(deletion)
                rows = f"""
                    SELECT * FROM Menu WHERE name = '{dish_name}'
                """
                row = self.db_manager.fetch_data(rows)
                if not row:
                    return "Deletion Addressed and deleted"
                else:
                    return "Deletion Addressed but Not deleted"
            else:
                return check_avail

    def check_availability(self, dish_name):

        print("Availability addressed")
        s_n = f"""
                SELECT availability FROM Menu 
                WHERE name = '{dish_name}'
            """
        result = self.db_manager.fetch_data(s_n)
        if result:
            if 1 in result[0]:
                return "Dish AVAILABLE"
            else:
                return "Dish UNAVAILABLE"
        else:
            return "No such dish in our Menu"

    def process_bill(self, table_no):

        query = f"""SELECT * FROM tables where table_no = {table_no}"""
        table_data = self.db_manager.fetch_data(query)
        return table_data

    def food_waste_calc(self, amount, waste_tax):
        waste_tax += (amount * (7 / 100))
        amount += waste_tax
        return amount, waste_tax

    def feed_back(self, feed):


        pos, neg = 0, 0
        g_keys = ['good', 'nice', 'great', 'awesome', 'very nice', 'best', 'tasty', 'delicious', 'yummy']
        b_keys = ['could have been better', 'bad', 'not nice', 'very bad', 'worst', 'could be better']

        for feeds in g_keys:
            if feeds in feed:
                pos += 1
                break

        for feeds in b_keys:
            if feeds in feed:
                neg += 1
                break

        data_update = f"""UPDATE review SET g_feed = g_feed + {pos} , b_feed = b_feed + {neg} where feed_no = 1"""
        self.db_manager.execute_query(data_update)

    def fetch_feed_back(self):
        data = f"""select g_feed, b_feed from review"""
        review = self.db_manager.fetch_data(data)
        return review

    def end_day(self, total_collection, waste_tax):

        data = f"""INSERT INTO REVENUE 
            VALUES (CURDATE(), "{total_collection}", CURTIME(), "{waste_tax}")
            """

        self.db_manager.execute_query(data)

class CUSTOMER:
    def __init__(self, db_manager):
        self.db_manager = db_manager

    def check_user_exists(self, mobile):
        '''check if user already exists in db'''

        user = f"""
            SELECT * FROM customers where custMobNo = '{mobile}'
        """
        data = self.db_manager.fetch_data(user)
        return data

    def add_customer(self, user_name, mobile, email_add):

        customers = """
            CREATE TABLE IF NOT EXISTS customers (
                customer_no INT AUTO_INCREMENT PRIMARY KEY,
                customerName VARCHAR(255),
                custMobNo varchar(20),
                customerMail varchar(255)
            )
        """
        self.db_manager.execute_query(customers)

        add_user = f""" 
            INSERT INTO customers(customerName, custMobNo, customerMail)
            Values('{user_name}', '{mobile}', '{email_add}')
        """
        self.db_manager.execute_query(add_user)

    def check_dish_available(self, dish_id):
        row = f"""SELECT name, price from Menu 
            WHERE dishId = {dish_id} and availability = 1
            """
        dish = self.db_manager.fetch_data(row)
        return dish

    def display_menu(self):
        row = """ SELECT dishId, name, price FROM Menu"""
        rows = self.db_manager.fetch_data(row)
        return rows
